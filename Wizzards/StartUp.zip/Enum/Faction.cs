﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Enum
{
   public enum Faction
    {
        CSharp,
        Java
    }
}
